"""Run a fresh 15-second pilot using this immutable historical core snapshot."""
import argparse,json
from pathlib import Path
from trafficlab.scenario import Config
from trafficlab.controllers import make_controller
from trafficlab.runner import run_episode
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--controllers',nargs='+',choices=['gurobi','microsoft','jev','luna','sol-medium'],default=['gurobi'])
p.add_argument('--output-dir',type=Path,required=True)
a=p.parse_args()
if a.output_dir.exists(): raise ValueError('Choose a new output directory; no silent overwrite or retries')
a.output_dir.mkdir(parents=True)
for name in a.controllers:
 c=make_controller(name,horizon=15)
 try:
  d=a.output_dir/name
  r=run_episode(Config(seed=7,duration=120,planning_horizon=15),c,output_dir=d,trace_file=d/'replay.json').record()
  with (a.output_dir/'runs.jsonl').open('a') as f: f.write(json.dumps(r)+'\n')
  print(name,r['completed'],flush=True)
 finally:
  if hasattr(c,'environment'): c.environment.dispose()
